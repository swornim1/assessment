Instructions:
1. Open index.html in your browser
2. You can navigate to Part 1 and Part 2 using the buttons.
3. In 'Part1' user can click and drag the mouse to generate the circle. The initial blue circle will be generated as user is dragging the mouse. 
   Once the mouse button is pressed the grids will turn blue and the farthest and closet red circle will be created. User can create multiple circle
   or reset the screen using reset button. User can navigate to the home screen or 'Part2' using the buttons in the screen.
4. In 'Part 2' user can toggle the grids and use generate button to find the best fitting circle. The program uses iterative, geometric least 
   squares-based algorithm for generating the best fitting square.
